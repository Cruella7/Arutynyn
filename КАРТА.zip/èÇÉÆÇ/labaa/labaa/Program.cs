﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labaa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, m, t, f, w;
            Console.WriteLine("Введите три числа:");
            a = Convert.ToInt32(Console.ReadLine());
            m = Convert.ToInt32(Console.ReadLine());
            t = Convert.ToInt32(Console.ReadLine());
            int Math.sin
        }
    }
}
