﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labaMat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                float F, f1, f2, f3, f4, f5;

                f1 = ((7 - 5.5f) / 0.03f);
                f2 = (float)(Math.Sqrt(3.05 + 3.62) * 4);
                f3 = (float)(Math.Pow(Math.Sqrt(0.3 - 3 / 20), 4) * 1.5);
                f4 = (1.88f + 2.12f) * 0.0125f;
                f5 = (float)Math.Pow(0.2, Math.Sqrt(3));

                F = ((float)(Math.Sqrt(f1 / f2) - f3 / f4)) * f5;

                Console.WriteLine(F);

                Console.ReadLine();
            }
        }
    }
}
